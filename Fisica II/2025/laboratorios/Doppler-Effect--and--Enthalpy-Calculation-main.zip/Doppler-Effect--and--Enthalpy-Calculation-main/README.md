# First Project : Doppler Effect and Frequency Shifts
# Second Project : Cálculo de Entalpía y Energía Interna en Reacciones Químicas

python -m venv venv
source ./venv/bin/activate 
pip install contourpy cycler fonttools kiwisolver matplotlib numpy packaging pillow pyparsing python-dateutil six
