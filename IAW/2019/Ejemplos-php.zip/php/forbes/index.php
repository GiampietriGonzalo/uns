﻿<html>
  <head>
    <title>Top Ricos - Forbes</title>
	  <link rel="stylesheet" type="text/css" href="estilo.css" >
  </head>
  <body>
	<p>Las personas más ricas del Mundo, según Forbes</p>

	<?php

		$arch = "datos.dat";
		$empresarios = file($arch,FILE_IGNORE_NEW_LINES);

		echo "<table border='1'>";
		echo "<thead><th>Nombre</th><th>Fuente de Ingreso</th><th>Pais</th><th>Billones de dólares</th></thead>";
		foreach($empresarios as $empresario){
			$registro = explode("|-|",$empresario);
			$bandera = strtolower($registro[2]).".png";
			$dinero =$registro[3];
			$auxlongitud = ($dinero-20)*10;

			echo "<tr>";
			 echo "<td>$registro[0] </td><td> $registro[1] </td>";
			 echo "<td align='center'> <img src='imagenes/$bandera'> </td>";
			 echo "<td> <img src='imagenes/box.jpg' width='$auxlongitud' height='10'>
						<img src='imagenes/dollar.png'>
				   </td>";
			echo "</tr>";
		}
		echo "</table>";
	?>


  </body>
</html>
