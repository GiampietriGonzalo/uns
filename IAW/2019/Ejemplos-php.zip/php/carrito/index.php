<?php
	session_start();
	if(sizeof($_SESSION)==0){
		$_SESSION['pez']=0;
		$_SESSION['gato']=0;
		$_SESSION['perro']=0;
		$_SESSION['loro']=0;
	};
	if(isset($_GET['accion'])){
		if ($_GET['accion']=="comprar"){
			switch($_GET['producto']){
			case 1: $_SESSION['pez']++;
					$mensaje= "Ha comprado un pez";
					break;
			case 2: $_SESSION['gato']++;
					$mensaje= "Ha comprado un gato";
					break;
			case 3: $_SESSION['perro']++;
					$mensaje= "Ha comprado un perro";
					break;
			case 4: $_SESSION['loro']++;
					$mensaje= "Ha comprado un loro";
					break;
			}
		}
		else if ($_GET['accion']=="mostrar"){
			$mensaje = "Tiene ".$_SESSION['pez']." peces, ".$_SESSION['gato']." gatos, ".$_SESSION['perro']." perros y ".$_SESSION['loro']." loros";
		}
		else if ($_GET['accion']=="borrar"){
			session_destroy();
			$mensaje = "Ha vaciado el carrito";
		}
	}

?>

<html>
	<head>
		<title>
			Carrito
		</title>
		<link rel="stylesheet" type="text/css" href="estilos.css" >
	</head>
	<body>
		<div class="productos">
		<a href="index.php?accion=comprar&producto=1"><img src="pez.png" border="0"></a>
		<a href="index.php?accion=comprar&producto=2"><img src="gato.png" border="0"></a>
		<a href="index.php?accion=comprar&producto=3"><img src="perro.png" border="0"></a>
		<a href="index.php?accion=comprar&producto=4"><img src="loro.png" border="0"></a>
		</div>
		<div class="acciones">
		<a href="index.php?accion=mostrar"><img src="carrito.png" border="0"></a>
		<a href="index.php?accion=borrar"><img src="borrar.png" border="0"></a>
		</div>
		<div>
		<?php  if (isset($mensaje)) { echo $mensaje; } ?>
		</div>
				
	</body>
</html>
