
<html>
  <head>
    <title>Voces!</title>
  </head>
  <body>

		<?php
	
			$nombre = $_GET["nombreusuario"];
			$personaje = $_GET["personaje"];
			
			$voces = array(	"Homero"=>"Dan Castellaneta", 
							"Duffman"=>"Hank Azaria", 
							"Frank Grimes"=>"Hank Azaria", 
							"Troy McLure"=>"Phil Hartman"	);
			
			
			$mensaje = "Hola $nombre, has elegido a $personaje, cuya voz es la de $voces[$personaje]";
			echo $mensaje;	
			echo "<br>";
		?> 
		<img src="<?php echo "imagenes/".strtolower($personaje).".jpg"; ?>">
		<img src="<?php echo "imagenes/flecha.png"; ?>">
		<img src="<?php echo "imagenes/".strtolower($voces[$personaje]).".jpg"; ?>">
  </body>
</html>











