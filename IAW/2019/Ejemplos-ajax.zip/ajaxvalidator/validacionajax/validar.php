<?php

$arch = "usuarios.dat"; 
$archivo = file($arch);	  
$cant = count($archivo);	
	
$indice=0;	
$existe=false;
// Buscar el nombre de usuario!

while ($indice < $cant)
	{	$usuario = trim($archivo[$indice]); 
		$existe = ($existe||($usuario==$_GET['userid']));
		$indice++;
	} 

Header ( "Content-type: text/xml" ); 	
if($existe){ 
	echo "<valid>false</valid>";
} else {
	echo "<valid>true</valid>"; 
}


?>
