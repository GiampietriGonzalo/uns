
var ajax = new XMLHttpRequest();
ajax.onreadystatechange = procesarRequest;

function validateUserId() {
  var target = document.getElementById("userid");
	var url = "http://localhost/iaw/ajaxvalidator/validacionajax/validar.php?userid=" + encodeURIComponent(target.value);
    ajax.open("GET", url, true);
    ajax.send();
}

function procesarRequest () {
	  if (ajax.readyState == 4) { // completo ! !
		if (ajax.status == 200) { // exito ! !
		  actualizarPagina(ajax.responseXML);
        }
      }
}


function actualizarPagina(responseXML) {
// publicar el resultado y actuar acordemente
   var msg = responseXML.getElementsByTagName("valid")[0].firstChild.nodeValue;
   var mdiv = document.getElementById("userIdMessage");
   var submitBtn = document.getElementById("submit_btn");
   if (msg == "false"){
       // setear el estilo del div donde mostramos el mensaje
       mdiv.className = "bp_invalid";
	   // setear el mensaje
       mdiv.innerHTML = "User Id Inválido";
	   // desactivar el boton de submit
       submitBtn.disabled = true;
    } else {
       var mdiv = document.getElementById("userIdMessage");
       // setear el estilo del div donde mostramos el mensaje
       mdiv.className = "bp_valid";
       mdiv.innerHTML = "User Id Válido";
       submitBtn.disabled = false;
    }
}



function disableSubmitBtn() {
    var submitBtn = document.getElementById("submit_btn");
    submitBtn.disabled = true;
}
