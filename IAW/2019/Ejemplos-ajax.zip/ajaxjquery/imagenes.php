<?php

$indice = $_GET['indice'];
$epigrafe = array(	0=>"Me conoces de toda la vida!", 
					1=>"El caramelo de los mil usos!", 
					2=>"Iraquies de nuevo...", 
					3=>"Al chasquear los dedos la comida podr&iacute;a no aparecer"	);
			
$html = "<img src='images/img".$indice.".jpg' border=\'0\'>";
$html = $html."<div class='epigrafe'>".$epigrafe[$indice]."</div>";

$espera = rand(2,6);
sleep($espera);

echo $html;

?>